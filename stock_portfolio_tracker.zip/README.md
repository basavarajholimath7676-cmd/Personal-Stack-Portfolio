﻿# 📈 Stock Portfolio Tracker

A beginner-friendly yet feature-packed Stock Portfolio Tracker implemented in **Python** and **Flask**, with an interactive web dashboard and a console application based on standard Product Requirements (PRD v1.0).

---

## 🌟 Key Features

- **Predefined & Dynamic Stock Prices**:
  - Preloaded with major tech tickers (`AAPL: $180`, `TSLA: $250`, `GOOGL: $140`, `MSFT: $420`, `AMZN: $180`).
  - **Dynamic Stock Addition**: Add any custom ticker (e.g., `NVDA`, `META`) and set its price on the fly.
- **Robust Input Validation**:
  - Case-insensitive stock symbol lookup (`aapl` → `AAPL`).
  - Rejects empty, unknown, non-numeric, zero, or negative inputs with clear error messages.
- **Investment Calculations**:
  - Real-time `Investment Value = Price × Quantity`.
  - Automatic portfolio accumulation when adding more shares to existing positions.
  - Overall `Total Portfolio Investment` calculation.
- **Interactive Web Dashboard**:
  - Live metric cards (Total Portfolio Value, Active Positions, Total Shares).
  - Quick-pick market ticker chips.
  - Asset Allocation doughnut chart powered by Chart.js.
  - In-line share adjustment (`+` / `-`) and deletion.
- **One-Click Exports**:
  - **TXT**: Clean, formatted text summary table matching PRD specifications.
  - **CSV**: Structured spreadsheet file with stock data and total row.
- **Multiple Modes**:
  - Flask Web Server (`app.py`)
  - Standalone Zero-Dependency Browser App (`portfolio_tracker.html`)
  - Console CLI Application (`portfolio_tracker.py`)

---

## 📁 Project Structure

```
stock-portfolio-tracker/
├── app.py                     # Flask web server & REST endpoints
├── portfolio_tracker.py       # Standalone CLI console application
├── portfolio_tracker.html     # Standalone single-file browser app (zero server needed)
├── test_app.py                # Unit test suite (13 automated test cases)
├── requirements.txt           # Python dependencies
├── .gitignore                 # Git ignore rules
├── templates/
│   └── index.html             # Dashboard UI template
└── static/
    ├── css/
    │   └── style.css          # Modern dark-mode fintech dashboard styling
    └── js/
        └── app.js             # Client-side dynamic controller & Chart.js logic
```

---

## 🚀 Getting Started

### 1. Prerequisites
- Python 3.8+ installed on your system.

### 2. Installation
Clone the repository and install requirements:
```bash
git clone https://github.com/<YOUR_USERNAME>/stock-portfolio-tracker.git
cd stock-portfolio-tracker
pip install -r requirements.txt
```

---

## 💻 Usage

### Option A: Run the Web Application (Recommended)
```bash
python app.py
```
Open your browser and navigate to:
**`http://127.0.0.1:5000`**

### Option B: Standalone In-Browser (No Server Required)
Simply double-click `portfolio_tracker.html` to open it in Chrome, Edge, or Firefox.

### Option C: Run the Console Application
```bash
python portfolio_tracker.py
```

---

## 🧪 Running Automated Tests

Run the test suite with Python's built-in `unittest`:
```bash
python -m unittest test_app.py
```

---

## 📄 License
This project is open-source and available under the [MIT License](LICENSE).
