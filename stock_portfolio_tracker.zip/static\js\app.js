/**
 * Stock Portfolio Tracker - Web Edition
 * Client-side Controller & Dynamic UI Management
 */

let availableStocks = {};
let allocationChart = null;

// Initialize on DOM load
document.addEventListener("DOMContentLoaded", () => {
    fetchPortfolio();
    setupEventListeners();
});

function setupEventListeners() {
    const form = document.getElementById("addStockForm");
    const stockInput = document.getElementById("stockInput");
    const quantityInput = document.getElementById("quantityInput");

    // Live calculation preview
    stockInput.addEventListener("input", updatePreview);
    quantityInput.addEventListener("input", updatePreview);

    // Form submission
    form.addEventListener("submit", handleAddStock);
}

/**
 * Updates the estimated value preview in real time
 */
function updatePreview() {
    const stockInput = document.getElementById("stockInput").value.trim().toUpperCase();
    const quantityInput = parseInt(document.getElementById("quantityInput").value, 10);
    const previewEl = document.getElementById("previewAmount");

    if (stockInput && availableStocks[stockInput] && !isNaN(quantityInput) && quantityInput > 0) {
        const price = availableStocks[stockInput];
        const val = price * quantityInput;
        previewEl.textContent = `$${val.toLocaleString()}`;
        previewEl.style.color = "var(--accent-green)";
    } else {
        previewEl.textContent = "$0";
        previewEl.style.color = "var(--text-muted)";
    }
}

/**
 * Click-to-fill handler for the market ticker chips
 */
function selectStock(symbol) {
    const stockInput = document.getElementById("stockInput");
    const quantityInput = document.getElementById("quantityInput");

    stockInput.value = symbol.toUpperCase();
    if (!quantityInput.value || parseInt(quantityInput.value, 10) <= 0) {
        quantityInput.value = 1;
    }
    quantityInput.focus();
    updatePreview();
}

function toggleNewStockForm() {
    const container = document.getElementById("newStockFormContainer");
    container.classList.toggle("d-none");
    if (!container.classList.contains("d-none")) {
        document.getElementById("newSymbolInput").focus();
    }
}

async function handleAddNewStock(event) {
    event.preventDefault();
    clearAlert();

    const symbolInput = document.getElementById("newSymbolInput");
    const priceInput = document.getElementById("newPriceInput");
    const symbol = symbolInput.value.trim().toUpperCase();
    const price = parseFloat(priceInput.value);

    if (!symbol) {
        showAlert("Please enter a stock symbol.", "error");
        return;
    }
    if (isNaN(price) || price <= 0) {
        showAlert("Please enter a valid stock price greater than zero.", "error");
        return;
    }

    try {
        const response = await fetch("/api/stocks/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symbol, price })
        });
        const result = await response.json();

        if (response.ok && result.success) {
            showAlert(result.message, "success");
            availableStocks = result.stocks;
            renderTickerChips(availableStocks);
            symbolInput.value = "";
            priceInput.value = "";
            toggleNewStockForm();
            selectStock(symbol);
        } else {
            showAlert(result.error || "Failed to add stock.", "error");
        }
    } catch (err) {
        showAlert("Network error. Could not add stock.", "error");
    }
}

function renderTickerChips(stocks) {
    const container = document.getElementById("tickerChips");
    if (!container) return;
    container.innerHTML = "";
    for (const [symbol, price] of Object.entries(stocks)) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ticker-chip";
        btn.onclick = () => selectStock(symbol);
        btn.innerHTML = `<span class="chip-symbol">${symbol}</span><span class="chip-price">$${price}</span>`;
        container.appendChild(btn);
    }
}

/**
 * Fetches portfolio state and stock prices from backend
 */
async function fetchPortfolio() {
    try {
        const response = await fetch("/api/portfolio");
        const data = await response.json();
        if (data.success) {
            availableStocks = data.stocks || {};
            renderTickerChips(availableStocks);
            renderPortfolio(data.items, data.total_investment);
        }
    } catch (err) {
        showAlert("Error connecting to server.", "error");
    }
}

/**
 * Handles adding or accumulating stock via AJAX
 */
async function handleAddStock(e) {
    e.preventDefault();
    clearAlert();

    const stockInput = document.getElementById("stockInput");
    const quantityInput = document.getElementById("quantityInput");
    const symbol = stockInput.value.trim();
    const quantity = quantityInput.value.trim();

    // Client-side quick checks matching Section 10
    if (!symbol) {
        showAlert("Stock symbol cannot be empty. Please enter a stock symbol.", "error");
        stockInput.focus();
        return;
    }

    const qtyNumber = Number(quantity);
    if (!quantity || isNaN(qtyNumber) || !Number.isInteger(qtyNumber)) {
        showAlert("Invalid quantity. Please enter a valid whole number (e.g., 5).", "error");
        quantityInput.focus();
        return;
    }

    if (qtyNumber <= 0) {
        showAlert("Quantity must be greater than zero. Please enter a positive integer.", "error");
        quantityInput.focus();
        return;
    }

    try {
        const response = await fetch("/api/portfolio/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ stock: symbol, quantity: qtyNumber })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showAlert(result.message, "success");
            renderPortfolio(result.items, result.total_investment);
            stockInput.value = "";
            quantityInput.value = "";
            updatePreview();
        } else {
            showAlert(result.error || "Failed to add stock.", "error");
        }
    } catch (err) {
        showAlert("Network error. Could not connect to server.", "error");
    }
}

/**
 * Removes a stock from the portfolio
 */
async function removeStock(symbol) {
    if (!confirm(`Are you sure you want to remove ${symbol} from your portfolio?`)) {
        return;
    }

    try {
        const response = await fetch("/api/portfolio/remove", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ stock: symbol })
        });

        const result = await response.json();
        if (result.success) {
            showAlert(result.message, "success");
            renderPortfolio(result.items, result.total_investment);
        }
    } catch (err) {
        showAlert("Failed to remove stock.", "error");
    }
}

/**
 * Quick increment/decrement quantity
 */
async function adjustQuantity(symbol, currentQty, delta) {
    const newQty = currentQty + delta;
    try {
        const response = await fetch("/api/portfolio/update", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ stock: symbol, quantity: newQty })
        });
        const result = await response.json();
        if (result.success) {
            renderPortfolio(result.items, result.total_investment);
        }
    } catch (err) {
        showAlert("Failed to update quantity.", "error");
    }
}

/**
 * Clears all holdings from portfolio
 */
async function clearPortfolio() {
    if (!confirm("Are you sure you want to clear your entire portfolio?")) {
        return;
    }

    try {
        const response = await fetch("/api/portfolio/clear", {
            method: "POST",
            headers: { "Content-Type": "application/json" }
        });
        const result = await response.json();
        if (result.success) {
            showAlert("Portfolio has been cleared.", "success");
            renderPortfolio([], 0);
        }
    } catch (err) {
        showAlert("Failed to clear portfolio.", "error");
    }
}

/**
 * Renders table rows, metrics, and updates allocation chart
 */
function renderPortfolio(items, totalInvestment) {
    const tbody = document.getElementById("portfolioTableBody");
    const emptyMsg = document.getElementById("emptyTableMessage");
    const tableTotal = document.getElementById("tableTotal");
    const totalValEl = document.getElementById("totalValueDisplay");
    const totalHoldingsEl = document.getElementById("totalHoldingsDisplay");
    const totalSharesEl = document.getElementById("totalSharesDisplay");

    tbody.innerHTML = "";

    let totalShares = 0;

    if (!items || items.length === 0) {
        emptyMsg.classList.remove("d-none");
        tableTotal.textContent = "$0";
        totalValEl.textContent = "$0";
        totalHoldingsEl.textContent = "0";
        totalSharesEl.textContent = "0";
        updateChart([]);
        return;
    }

    emptyMsg.classList.add("d-none");

    items.forEach(item => {
        totalShares += item.quantity;
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><span class="stock-badge">${item.stock}</span></td>
            <td>$${item.price.toLocaleString()}</td>
            <td>
                <button class="btn btn-sm btn-secondary" onclick="adjustQuantity('${item.stock}', ${item.quantity}, -1)" title="Decrease shares">-</button>
                <span style="display:inline-block; min-width:30px; text-align:center;">${item.quantity}</span>
                <button class="btn btn-sm btn-secondary" onclick="adjustQuantity('${item.stock}', ${item.quantity}, 1)" title="Increase shares">+</button>
            </td>
            <td><strong>$${item.value.toLocaleString()}</strong></td>
            <td class="text-right">
                <button class="btn btn-sm btn-danger" onclick="removeStock('${item.stock}')" title="Delete holding">Remove</button>
            </td>
        `;
        tbody.appendChild(tr);
    });

    tableTotal.textContent = `$${totalInvestment.toLocaleString()}`;
    totalValEl.textContent = `$${totalInvestment.toLocaleString()}`;
    totalHoldingsEl.textContent = items.length;
    totalSharesEl.textContent = totalShares.toLocaleString();

    updateChart(items);
}

/**
 * Updates the Chart.js doughnut chart for asset allocation
 */
function updateChart(items) {
    const canvas = document.getElementById("allocationChart");
    const placeholder = document.getElementById("chartPlaceholder");

    if (!items || items.length === 0) {
        canvas.style.display = "none";
        placeholder.style.display = "block";
        if (allocationChart) {
            allocationChart.destroy();
            allocationChart = null;
        }
        return;
    }

    canvas.style.display = "block";
    placeholder.style.display = "none";

    const labels = items.map(i => i.stock);
    const data = items.map(i => i.value);
    const backgroundColors = [
        "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6",
        "#ec4899", "#06b6d4", "#14b8a6", "#f97316"
    ];

    if (allocationChart) {
        allocationChart.data.labels = labels;
        allocationChart.data.datasets[0].data = data;
        allocationChart.update();
    } else {
        const ctx = canvas.getContext("2d");
        allocationChart = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors.slice(0, items.length),
                    borderColor: "#1e293b",
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: {
                            color: "#94a3b8",
                            boxWidth: 12,
                            padding: 15,
                            font: { family: "Inter", size: 12 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                const val = context.raw || 0;
                                return ` ${context.label}: $${val.toLocaleString()}`;
                            }
                        }
                    }
                },
                cutout: "68%"
            }
        });
    }
}

/**
 * Displays feedback alerts
 */
function showAlert(message, type) {
    const alertBox = document.getElementById("alertBox");
    alertBox.textContent = message;
    alertBox.className = `alert alert-${type}`;
    alertBox.classList.remove("d-none");

    if (type === "success") {
        setTimeout(() => {
            alertBox.classList.add("d-none");
        }, 4000);
    }
}

function clearAlert() {
    const alertBox = document.getElementById("alertBox");
    alertBox.classList.add("d-none");
}
